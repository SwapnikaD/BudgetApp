import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { TrendingUp, TrendingDown, Wallet, Target } from 'lucide-react';

interface BudgetSummaryProps {
  totalIncome: number;
  totalSpent: number;
  totalSaved: number;
  totalBudget: number;
}

export function BudgetSummary({ totalIncome, totalSpent, totalSaved, totalBudget }: BudgetSummaryProps) {
  const netSavings = totalIncome - totalSpent;
  const budgetStatus = totalSpent <= totalBudget ? 'pass' : 'fail';
  const savingsRate = (netSavings / totalIncome) * 100;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Total Income</span>
          <TrendingUp className="w-4 h-4 text-green-600" />
        </div>
        <p className="text-green-600">${totalIncome.toFixed(2)}</p>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Total Spent</span>
          <TrendingDown className="w-4 h-4 text-red-600" />
        </div>
        <div className="flex items-center justify-between">
          <p className="text-red-600">${totalSpent.toFixed(2)}</p>
          <Badge variant={budgetStatus === 'pass' ? 'default' : 'destructive'}>
            {budgetStatus === 'pass' ? '✓ Pass' : '✗ Over'}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Budget: ${totalBudget.toFixed(2)}
        </p>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Net Savings</span>
          <Wallet className="w-4 h-4 text-blue-600" />
        </div>
        <p className="text-blue-600">${netSavings.toFixed(2)}</p>
        <p className="text-xs text-muted-foreground mt-1">
          Savings Rate: {savingsRate.toFixed(1)}%
        </p>
      </Card>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Goal Savings</span>
          <Target className="w-4 h-4 text-purple-600" />
        </div>
        <p className="text-purple-600">${totalSaved.toFixed(2)}</p>
      </Card>
    </div>
  );
}
