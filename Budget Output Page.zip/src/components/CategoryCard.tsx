import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ChevronRight, ShoppingCart, Car, Home, Sofa, Film, Utensils, Heart, ShoppingBag } from 'lucide-react';
import { Category } from '../types/budget';

interface CategoryCardProps {
  category: Category;
  onClick: () => void;
}

const iconMap: Record<string, any> = {
  ShoppingCart,
  Car,
  Home,
  Sofa,
  Film,
  Utensils,
  Heart,
  ShoppingBag,
};

export function CategoryCard({ category, onClick }: CategoryCardProps) {
  const Icon = iconMap[category.icon] || ShoppingCart;
  const percentage = (category.spent / category.budget) * 100;
  const isOverBudget = category.spent > category.budget;
  const remaining = category.budget - category.spent;

  return (
    <Card 
      className="p-4 hover:shadow-md transition-shadow cursor-pointer" 
      onClick={onClick}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${isOverBudget ? 'bg-red-100' : 'bg-blue-100'}`}>
            <Icon className={`w-5 h-5 ${isOverBudget ? 'text-red-600' : 'text-blue-600'}`} />
          </div>
          <div>
            <h3>{category.name}</h3>
            <p className="text-sm text-muted-foreground">
              ${category.spent.toFixed(2)} of ${category.budget.toFixed(2)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isOverBudget ? 'destructive' : 'secondary'}>
            {isOverBudget ? 'Over' : 'On Track'}
          </Badge>
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </div>
      </div>
      
      <Progress value={Math.min(percentage, 100)} className="h-2 mb-2" />
      
      <div className="flex justify-between text-sm">
        <span className="text-muted-foreground">
          {isOverBudget ? 'Over by' : 'Remaining'}
        </span>
        <span className={isOverBudget ? 'text-red-600' : 'text-green-600'}>
          ${Math.abs(remaining).toFixed(2)}
        </span>
      </div>
    </Card>
  );
}
