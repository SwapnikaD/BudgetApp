import { Card } from './ui/card';
import { Plus, DollarSign } from 'lucide-react';
import { Income } from '../types/budget';
import { Button } from './ui/button';

interface IncomeSectionProps {
  incomes: Income[];
  totalIncome: number;
}

export function IncomeSection({ incomes, totalIncome }: IncomeSectionProps) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-green-600" />
          Income
        </h2>
        <Button size="sm" variant="outline">
          <Plus className="w-4 h-4 mr-1" />
          Add
        </Button>
      </div>
      
      <div className="space-y-3">
        {incomes.map((income) => (
          <div key={income.id} className="flex justify-between items-center py-2 border-b last:border-b-0">
            <span className="text-muted-foreground">{income.source}</span>
            <span className="text-green-600">${income.amount.toFixed(2)}</span>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t">
        <div className="flex justify-between items-center">
          <span>Total Income</span>
          <span className="text-green-600">${totalIncome.toFixed(2)}</span>
        </div>
      </div>
    </Card>
  );
}
