import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from './ui/drawer';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Category, Expense } from '../types/budget';
import { Calendar, TrendingDown } from 'lucide-react';

interface ExpenseDetailsDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category: Category | null;
  expenses: Expense[];
}

export function ExpenseDetailsDrawer({ open, onOpenChange, category, expenses }: ExpenseDetailsDrawerProps) {
  if (!category) return null;

  const categoryExpenses = expenses
    .filter(e => e.category === category.name)
    .sort((a, b) => b.amount - a.amount);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>{category.name} Expenses</DrawerTitle>
          <DrawerDescription>
            Total spent: ${category.spent.toFixed(2)} of ${category.budget.toFixed(2)} budget
          </DrawerDescription>
        </DrawerHeader>
        
        <div className="px-4 pb-8">
          <ScrollArea className="h-[400px]">
            <div className="space-y-1">
              {categoryExpenses.map((expense, index) => (
                <div key={expense.id}>
                  <div className="flex items-center justify-between py-3 px-2 hover:bg-accent rounded-md">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary text-sm mt-1">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p>{expense.name}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(expense.date)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p>${expense.amount.toFixed(2)}</p>
                    </div>
                  </div>
                  {index < categoryExpenses.length - 1 && <Separator />}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
