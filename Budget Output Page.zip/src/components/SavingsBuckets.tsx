import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Shield, Plane, Car, Hammer, TrendingUp, Target } from 'lucide-react';
import { SavingsBucket } from '../types/budget';

interface SavingsBucketsProps {
  buckets: SavingsBucket[];
  totalSaved: number;
}

const iconMap: Record<string, any> = {
  Shield,
  Plane,
  Car,
  Hammer,
  TrendingUp,
};

export function SavingsBuckets({ buckets, totalSaved }: SavingsBucketsProps) {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Target className="w-5 h-5 text-purple-600" />
        <h2>Savings Goals</h2>
      </div>
      
      <div className="space-y-4">
        {buckets.map((bucket) => {
          const Icon = iconMap[bucket.icon] || Shield;
          const percentage = (bucket.saved / bucket.goal) * 100;
          const isComplete = bucket.saved >= bucket.goal;
          
          return (
            <div key={bucket.id} className="p-4 rounded-lg border bg-card">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isComplete ? 'bg-green-100' : 'bg-purple-100'}`}>
                    <Icon className={`w-4 h-4 ${isComplete ? 'text-green-600' : 'text-purple-600'}`} />
                  </div>
                  <div>
                    <p>{bucket.name}</p>
                    <p className="text-sm text-muted-foreground">
                      ${bucket.saved.toFixed(2)} of ${bucket.goal.toFixed(2)}
                    </p>
                  </div>
                </div>
                <Badge variant={isComplete ? 'default' : 'secondary'}>
                  {isComplete ? '✓ Complete' : `${percentage.toFixed(0)}%`}
                </Badge>
              </div>
              
              <Progress value={Math.min(percentage, 100)} className="h-2" />
            </div>
          );
        })}
      </div>
      
      <div className="mt-6 pt-4 border-t">
        <div className="flex justify-between items-center">
          <span>Total Saved</span>
          <span className="text-purple-600">${totalSaved.toFixed(2)}</span>
        </div>
      </div>
    </Card>
  );
}
