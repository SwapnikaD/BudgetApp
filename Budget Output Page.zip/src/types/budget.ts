export interface Expense {
  id: string;
  name: string;
  amount: number;
  date: string;
  category: string;
}

export interface Category {
  id: string;
  name: string;
  budget: number;
  spent: number;
  icon: string;
}

export interface Income {
  id: string;
  source: string;
  amount: number;
}

export interface SavingsBucket {
  id: string;
  name: string;
  goal: number;
  saved: number;
  icon: string;
}
