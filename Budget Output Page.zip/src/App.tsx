import { useState } from 'react';
import { IncomeSection } from './components/IncomeSection';
import { CategoryCard } from './components/CategoryCard';
import { ExpenseDetailsDrawer } from './components/ExpenseDetailsDrawer';
import { SavingsBuckets } from './components/SavingsBuckets';
import { BudgetCharts } from './components/BudgetCharts';
import { BudgetSummary } from './components/BudgetSummary';
import { mockIncomes, mockCategories, mockExpenses, mockSavingsBuckets } from './data/mockBudgetData';
import { Category } from './types/budget';
import { Calendar } from 'lucide-react';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const totalIncome = mockIncomes.reduce((sum, income) => sum + income.amount, 0);
  const totalSpent = mockCategories.reduce((sum, cat) => sum + cat.spent, 0);
  const totalBudget = mockCategories.reduce((sum, cat) => sum + cat.budget, 0);
  const totalSaved = mockSavingsBuckets.reduce((sum, bucket) => sum + bucket.saved, 0);

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category);
    setDrawerOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1>Budget Dashboard</h1>
              <p className="text-muted-foreground mt-1">November 2025</p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg border bg-card">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Monthly View</span>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="mb-8">
          <BudgetSummary 
            totalIncome={totalIncome}
            totalSpent={totalSpent}
            totalSaved={totalSaved}
            totalBudget={totalBudget}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Income Section */}
          <div className="lg:col-span-1">
            <IncomeSection incomes={mockIncomes} totalIncome={totalIncome} />
          </div>

          {/* Savings Buckets */}
          <div className="lg:col-span-2">
            <SavingsBuckets buckets={mockSavingsBuckets} totalSaved={totalSaved} />
          </div>
        </div>

        {/* Charts Section */}
        <div className="mb-8">
          <BudgetCharts categories={mockCategories} savingsBuckets={mockSavingsBuckets} />
        </div>

        {/* Spending Categories */}
        <div>
          <h2 className="mb-4">Spending Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {mockCategories.map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                onClick={() => handleCategoryClick(category)}
              />
            ))}
          </div>
        </div>

        {/* Expense Details Drawer */}
        <ExpenseDetailsDrawer
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
          category={selectedCategory}
          expenses={mockExpenses}
        />
      </div>
    </div>
  );
}
