import { Category, Expense, Income, SavingsBucket } from '../types/budget';

export const mockIncomes: Income[] = [
  { id: '1', source: 'Salary - Primary', amount: 5500 },
  { id: '2', source: 'Salary - Secondary', amount: 3200 },
  { id: '3', source: 'Freelance Work', amount: 800 },
];

export const mockCategories: Category[] = [
  { id: '1', name: 'Grocery', budget: 800, spent: 745.32, icon: 'ShoppingCart' },
  { id: '2', name: 'Transportation', budget: 400, spent: 456.80, icon: 'Car' },
  { id: '3', name: 'Rent/Utility', budget: 2500, spent: 2500.00, icon: 'Home' },
  { id: '4', name: 'Home Goods', budget: 300, spent: 234.56, icon: 'Sofa' },
  { id: '5', name: 'Entertainment', budget: 500, spent: 612.45, icon: 'Film' },
  { id: '6', name: 'Dining Out', budget: 450, spent: 389.20, icon: 'Utensils' },
  { id: '7', name: 'Healthcare', budget: 200, spent: 145.00, icon: 'Heart' },
  { id: '8', name: 'Shopping', budget: 400, spent: 523.67, icon: 'ShoppingBag' },
];

export const mockExpenses: Expense[] = [
  // Grocery
  { id: '1', name: 'Whole Foods - Weekly Shop', amount: 156.78, date: '2025-11-08', category: 'Grocery' },
  { id: '2', name: 'Trader Joes', amount: 89.45, date: '2025-11-06', category: 'Grocery' },
  { id: '3', name: 'Costco - Bulk Purchase', amount: 234.12, date: '2025-11-04', category: 'Grocery' },
  { id: '4', name: 'Local Market', amount: 67.89, date: '2025-11-03', category: 'Grocery' },
  { id: '5', name: 'Target - Groceries', amount: 98.34, date: '2025-11-02', category: 'Grocery' },
  { id: '6', name: 'Whole Foods', amount: 78.56, date: '2025-11-01', category: 'Grocery' },
  { id: '7', name: 'Corner Store', amount: 20.18, date: '2025-10-30', category: 'Grocery' },
  
  // Transportation
  { id: '8', name: 'Gas Station', amount: 65.00, date: '2025-11-07', category: 'Transportation' },
  { id: '9', name: 'Car Insurance', amount: 145.00, date: '2025-11-05', category: 'Transportation' },
  { id: '10', name: 'Uber Rides', amount: 89.80, date: '2025-11-04', category: 'Transportation' },
  { id: '11', name: 'Gas Station', amount: 58.00, date: '2025-11-01', category: 'Transportation' },
  { id: '12', name: 'Parking Fee', amount: 45.00, date: '2025-10-28', category: 'Transportation' },
  { id: '13', name: 'Metro Pass', amount: 54.00, date: '2025-10-25', category: 'Transportation' },
  
  // Rent/Utility
  { id: '14', name: 'Monthly Rent', amount: 1800.00, date: '2025-11-01', category: 'Rent/Utility' },
  { id: '15', name: 'Electric Bill', amount: 120.00, date: '2025-11-03', category: 'Rent/Utility' },
  { id: '16', name: 'Water Bill', amount: 45.00, date: '2025-11-03', category: 'Rent/Utility' },
  { id: '17', name: 'Internet', amount: 89.00, date: '2025-11-02', category: 'Rent/Utility' },
  { id: '18', name: 'Gas Bill', amount: 156.00, date: '2025-11-04', category: 'Rent/Utility' },
  { id: '19', name: 'HOA Fee', amount: 290.00, date: '2025-11-01', category: 'Rent/Utility' },
  
  // Home Goods
  { id: '20', name: 'Bed Bath & Beyond', amount: 89.99, date: '2025-11-05', category: 'Home Goods' },
  { id: '21', name: 'IKEA', amount: 67.45, date: '2025-11-02', category: 'Home Goods' },
  { id: '22', name: 'Target - Home', amount: 45.12, date: '2025-10-29', category: 'Home Goods' },
  { id: '23', name: 'Amazon - Household', amount: 32.00, date: '2025-10-27', category: 'Home Goods' },
  
  // Entertainment
  { id: '24', name: 'Movie Tickets', amount: 45.00, date: '2025-11-08', category: 'Entertainment' },
  { id: '25', name: 'Concert Tickets', amount: 156.00, date: '2025-11-06', category: 'Entertainment' },
  { id: '26', name: 'Netflix', amount: 15.99, date: '2025-11-05', category: 'Entertainment' },
  { id: '27', name: 'Spotify', amount: 10.99, date: '2025-11-05', category: 'Entertainment' },
  { id: '28', name: 'Museum Entry', amount: 25.00, date: '2025-11-03', category: 'Entertainment' },
  { id: '29', name: 'Gaming - Steam', amount: 59.99, date: '2025-11-02', category: 'Entertainment' },
  { id: '30', name: 'Books', amount: 34.99, date: '2025-10-30', category: 'Entertainment' },
  { id: '31', name: 'Disney+', amount: 13.99, date: '2025-10-28', category: 'Entertainment' },
  { id: '32', name: 'HBO Max', amount: 15.99, date: '2025-10-28', category: 'Entertainment' },
  { id: '33', name: 'Apple Arcade', amount: 4.99, date: '2025-10-26', category: 'Entertainment' },
  { id: '34', name: 'Board Game', amount: 45.52, date: '2025-10-25', category: 'Entertainment' },
  { id: '35', name: 'Bowling Night', amount: 38.00, date: '2025-10-24', category: 'Entertainment' },
  { id: '36', name: 'Escape Room', amount: 50.00, date: '2025-10-22', category: 'Entertainment' },
  { id: '37', name: 'Mini Golf', amount: 32.00, date: '2025-10-20', category: 'Entertainment' },
  { id: '38', name: 'Zoo Tickets', amount: 45.00, date: '2025-10-18', category: 'Entertainment' },
  { id: '39', name: 'Audible', amount: 14.95, date: '2025-10-15', category: 'Entertainment' },
  
  // Dining Out
  { id: '40', name: 'Restaurant - Dinner', amount: 89.50, date: '2025-11-08', category: 'Dining Out' },
  { id: '41', name: 'Coffee Shop', amount: 12.45, date: '2025-11-07', category: 'Dining Out' },
  { id: '42', name: 'Lunch - Mexican', amount: 45.00, date: '2025-11-06', category: 'Dining Out' },
  { id: '43', name: 'Breakfast Cafe', amount: 23.80, date: '2025-11-05', category: 'Dining Out' },
  { id: '44', name: 'Pizza Night', amount: 56.90, date: '2025-11-04', category: 'Dining Out' },
  { id: '45', name: 'Sushi Restaurant', amount: 78.65, date: '2025-11-02', category: 'Dining Out' },
  { id: '46', name: 'Coffee Shop', amount: 8.90, date: '2025-11-01', category: 'Dining Out' },
  { id: '47', name: 'Fast Food', amount: 18.50, date: '2025-10-31', category: 'Dining Out' },
  { id: '48', name: 'Thai Food', amount: 55.50, date: '2025-10-29', category: 'Dining Out' },
  
  // Healthcare
  { id: '49', name: 'Pharmacy - Medication', amount: 45.00, date: '2025-11-07', category: 'Healthcare' },
  { id: '50', name: 'Doctor Co-pay', amount: 35.00, date: '2025-11-04', category: 'Healthcare' },
  { id: '51', name: 'Dental Cleaning', amount: 65.00, date: '2025-11-01', category: 'Healthcare' },
  
  // Shopping
  { id: '52', name: 'Clothing Store', amount: 156.89, date: '2025-11-08', category: 'Shopping' },
  { id: '53', name: 'Amazon - Electronics', amount: 89.99, date: '2025-11-06', category: 'Shopping' },
  { id: '54', name: 'Shoes', amount: 98.50, date: '2025-11-04', category: 'Shopping' },
  { id: '55', name: 'Online Store', amount: 67.45, date: '2025-11-02', category: 'Shopping' },
  { id: '56', name: 'Department Store', amount: 45.67, date: '2025-10-30', category: 'Shopping' },
  { id: '57', name: 'Tech Store', amount: 65.17, date: '2025-10-28', category: 'Shopping' },
];

export const mockSavingsBuckets: SavingsBucket[] = [
  { id: '1', name: 'Emergency Fund', goal: 15000, saved: 12450.00, icon: 'Shield' },
  { id: '2', name: 'Vacation', goal: 5000, saved: 3200.00, icon: 'Plane' },
  { id: '3', name: 'New Car', goal: 8000, saved: 8500.00, icon: 'Car' },
  { id: '4', name: 'Home Renovation', goal: 10000, saved: 5600.00, icon: 'Hammer' },
  { id: '5', name: 'Investment', goal: 6000, saved: 6000.00, icon: 'TrendingUp' },
];
