
  # Budget Output Page

  This is a code bundle for Budget Output Page. The original project is available at https://www.figma.com/design/IAQsUuYl60GsPEu7WgkYU0/Budget-Output-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  